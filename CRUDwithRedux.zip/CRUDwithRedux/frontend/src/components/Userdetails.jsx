import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getOneUser } from '../../store/slice/slice';

const Userdetails = () => {
    const {id}=useParams()
    const dispatch = useDispatch();
    const {singleUser,loading} =useSelector(state=>state.app)
   // Dispatch the action to get the user details
  useEffect(() => {
    if (id) {
      dispatch(getOneUser(id));
    }
  }, [dispatch, id]);

  // Check if the data is still loading or if there's no user data yet
  if (loading) return <p>Loading...</p>;
  if (!singleUser) return <p>No user data available</p>;

  // Destructure properties safely after ensuring singleUser is defined
  const { age, email, gender, name, verified } = singleUser;
   
  return (
    <div>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
      <p>Email: {email}</p>
      <p>Gender: {gender}</p>
      <p>ID: {id}</p>
      <p>Verfied: {verified}</p>
    </div>
  )
}

export default Userdetails;
