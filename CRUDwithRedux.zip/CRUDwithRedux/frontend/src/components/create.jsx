import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { createUser } from '../../store/slice/slice'
import { useNavigate } from 'react-router-dom'

const Create = () => {
const [formData, setFormData] = useState({})
const dispatch= useDispatch()
const navigate= useNavigate()
function getData(e){
  setFormData({...formData,[e.target.name]:e.target.value})
console.log(formData)
}
function handleSubmit(e){
  e.preventDefault();
dispatch(createUser(formData))
navigate("/read")
}

  return (
    <div><form onSubmit={handleSubmit}>
      <div className="form-group">
      <label>Enter Your ID</label>
      <input onChange={getData} type="number" name="id" className="form-control" aria-describedby="emailHelp" placeholder="Enter ID" />
    </div>
     <div className="form-group">
      <label>Name</label>
      <input onChange={getData} type="text" name="name" className="form-control"  aria-describedby="emailHelp" placeholder="Enter Name" />
    </div>
    <div className="form-group">
      <label>Email address</label>
      <input onChange={getData} type="email" name="email" className="form-control"  aria-describedby="emailHelp" placeholder="Enter email" />
    </div>
    <div className="form-group">
      <label>Age</label>
      <input onChange={getData} type="text" name="age" className="form-control" placeholder="Enter Age"/>
    </div>
    <div className="form-group">
      <label >Select Gender</label>
    
    </div>
    <div className="form-check">
    
  <input onChange={getData} className="form-check-input" type="radio" name="gender"  value="Male" />
  <label className="form-check-label" >
   Male
  </label>
</div>
<div className="form-check">
  <input onChange={getData} className="form-check-input" type="radio" name="gender"  value="Female" />
  <label className="form-check-label" >
    Female
  </label>
</div>

    <div className="form-check">
      <input onChange={getData} name="verified" type="checkbox" className="form-check-input" value="yes" />
      <label className="form-check-label" >Are you a verified user?</label>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
  </form></div>
  )
}

export default Create;