import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./CustomModal.css";
import { useNavigate, useParams } from "react-router-dom";
import { updateUser } from "../../store/slice/slice";

const CustomModal = ({ id, setShowModal }) => {
//   const allusers = useSelector((state) => state.app.users);

//   const singleUser = allusers.filter((ele) => ele.id === id);
//   console.log("singleuser", singleUser);
// const [formData, setFormData] = useState(user)
// const dispatch= useDispatch()
// const navigate= useNavigate()
// function getData(e){
//   setFormData({...formData,[e.target.name]:e.target.value})
// console.log(formData)
// }
// function handleSubmit(e){
//   e.preventDefault();
// dispatch(updateUser(formData))
// navigate("/read")
// }

const dispatch = useDispatch();
const navigate = useNavigate();
const [updateData, setUpdateData] = useState();
console.log(id);
  const { users, loading } = useSelector((state) => state.app);
console.log(users)
  useEffect(() => {
    if (id) {
      const singleUser = users.filter((ele) => ele.id === id);
      setUpdateData(singleUser[0]);
      console.log(singleUser )
    }
  }, [id]);

  const getData = (e) => {
    setUpdateData({ ...updateData, [e.target.name]: e.target.value });
  };

  console.log("updated data", updateData);

  const handleUpdate = (e) => {
    e.preventDefault();
    dispatch(updateUser(updateData));
    navigate("/read");
    setShowModal(false)
  };
  return (
    <div className="modalBackground">
      <div className="modalContainer">
        <button onClick={() => setShowModal(false)}>Close</button>


        <div><form onSubmit={handleUpdate}>
      <div className="form-group">
      <label>Enter Your ID</label>
      <input onChange={getData} type="number" value={updateData && updateData.id} name="id" className="form-control" aria-describedby="emailHelp" placeholder="Enter ID" />
    </div>
     <div className="form-group">
      <label>Name</label>
      <input onChange={getData} type="text" name="name" value={updateData && updateData.name} className="form-control"  aria-describedby="emailHelp" placeholder="Enter Name" />
    </div>
    <div className="form-group">
      <label>Email address</label>
      <input onChange={getData} type="email" value={updateData && updateData.email} name="email" className="form-control"  aria-describedby="emailHelp" placeholder="Enter email" />
    </div>
    <div className="form-group">
      <label>Age</label>
      <input onChange={getData} type="text" name="age" value={updateData && updateData.age} className="form-control" placeholder="Enter Age"/>
    </div>
    <div className="form-group">
      <label >Select Gender</label>
    
    </div>
    <div className="form-check">
    
  <input onChange={getData} className="form-check-input" type="radio" name="gender"  value="Male" checked={updateData && updateData.gender==="Male"?true:false}  />
  <label className="form-check-label" >
   Male
  </label>
</div>
<div className="form-check">
  <input onChange={getData} className="form-check-input" type="radio" name="gender"  value="Female" checked={updateData && updateData.gender=="Female"?true:false}  />
  <label className="form-check-label" >
    Female
  </label>
</div>

    <div className="form-check">
      <input onChange={getData} name="verified" type="checkbox" className="form-check-input" value="yes" checked={updateData && updateData.verified=="yes"?true:false} />
      <label className="form-check-label" >Are you a verified user?</label>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
  </form></div>

        {/* <h2>{user.name}</h2>
        <h3>{user.email}</h3>
        <h3>{user.id}</h3>
        <h4>{user.age}</h4>
        <p>{user.gender}</p>
        <p>{user.verified}</p> */}
      </div>
    </div>
  );
};

export default CustomModal;