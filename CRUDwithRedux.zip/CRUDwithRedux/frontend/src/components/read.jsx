import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { deleteUser, showUser } from '../../store/slice/slice';
import { Link } from 'react-router-dom';
import CustomModal from './CustomModal';

const Read = () => {

  const dispatch = useDispatch(); // Get the dispatch function
  const { users, loading, error, searchData } = useSelector((state) => state.app); // Extract the required state from Redux store
  const [showModal, setShowModal]= useState(false)
  const [id, setId]= useState({})
  const [radioData,setRadioData] = useState("");

  // Dispatch the showUser action when the component mounts
  useEffect(() => {
    dispatch(showUser()); // Dispatch the API call action
  }, [dispatch,id]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  return (
    <div>
    <div>
    <div className="form-group">
      <label >Filter</label>
    
    </div>
    <div className="form-check">
    
    <input onChange={()=>setRadioData("")} className="form-check-input" type="radio" name="gender"  value="Male" checked={radioData===""?true:false}  />
    <label className="form-check-label" >
     All
    </label>
  </div>
    <div className="form-check">
    
  <input onChange={()=>setRadioData("Male")}  className="form-check-input" type="radio" name="gender"  value="Male" checked={radioData==="Male"?true:false}  />
  <label className="form-check-label" >
   Male
  </label>
</div>
<div className="form-check">
  <input onChange={()=>setRadioData("Female")}  className="form-check-input" type="radio" name="gender"  value="Female" checked={radioData==="Female"?true:false}  />
  <label className="form-check-label" >
    Female
  </label>
</div>
    </div>
    {showModal && <CustomModal id={id}  setShowModal={setShowModal}/>}
    {users && users.filter((ele) => {
              if (searchData.length === 0) {
                return ele;
              } else {
                return ele.name
                  .toLowerCase()
                  .includes(searchData.toLowerCase());
              }
            }).filter((ele) => {
              if (radioData=="") {
                return ele;
              } else if(radioData=="Male") {
                return ele.gender==="Male"
              }
              else if(radioData=="Female") {
                return ele.gender==="Female"
              }
            }).map((user,i)=>(
      <div className="card" key={i} >
  <div className="card-body">
    <h5 className="card-title">{user.name}</h5>
    <p className="card-text">{user.email}</p>
    <p className="card-text">{user.gender}</p>
    <p className="card-text">{user.verified==="yes"?"You are verified":"Verify your account"}</p>
    <Link to={`/user/${user.id}`} className="btn btn-primary">View More</Link>
  
    <button  className="btn btn-primary" onClick={()=>{setId(user.id);setShowModal(true)}}>Update</button>
    <button className="btn btn-secondary" onClick={()=>{dispatch(deleteUser(user.id))}}>Delete</button>
  </div>
</div>
    ))}
    </div>
  )
}

export default Read;
