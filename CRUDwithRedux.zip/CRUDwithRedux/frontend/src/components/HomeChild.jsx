import React from 'react'
import { Link } from 'react-router-dom'

const HomeChild = () => {
  return (
    <div>
       <Link to={"/create"}className="btn btn-outline-success create my-2  d-flex m-auto mt-3" type="submit" >
        Create User
      </Link>
    </div>
  )
}

export default HomeChild
