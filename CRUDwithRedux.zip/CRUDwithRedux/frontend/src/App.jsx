
import Navbar from "./components/navbar";
import "./App.css";
import Create from "./components/create";
import Read from "./components/read";
import Update from "./components/update";
import { Link, Outlet, useRoutes } from "react-router-dom";
import Home from "./components/Home";
import HomeChild from "./components/HomeChild";
import Userdetails from "./components/userdetails";
function App() {

  let element = useRoutes([
    {
      path: "/",
      element: <Home />,
      children: [
        { path: "/", element: <HomeChild /> },
        { path: "create", element: <Create /> },
        { path: "read", element: <Read /> },
        { path: "update", element: <Update /> },
        { path: "user/:id", element: <Userdetails /> },
      ],
    },
   
  ]);


  return element;
}
export default App;
